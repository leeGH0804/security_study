# CMDI-B-timepro-debug == CVE-2025-14485 -- verification results (a3004t_ml_14_190)

**Status: Evidence 3 -- full chain confirmed live under QEMU, real command
execution captured (`id` output), causation proven via negative control.**

This firmware version (14.190 = "14.19.0" per `home/httpd/version`) is the
exact version named in the public CVE-2025-14485 advisory ("EFM ipTIME
A3004T 14.19.0"). This session cross-referenced the public CVE against a
pre-existing CMDI-B-timepro-debug finding (found independently, before the
CVE comparison), corrected a transcription error in the public writeup,
fully resolved every previously-unknown gate/parameter, and then closed
every remaining gap by decompiling the three functions blocking the earlier
attempt -- reaching a genuine, reproducible `popen()` execution.

## CVE cross-reference

| | Public CVE-2025-14485 (VulDB/NVD) | This engagement |
|---|---|---|
| File | `/sess-bin/timepro.cgi` (routed via) | `cgibin/timepro.cgi` (same binary) |
| Function | `show_debug_screen` | `show_debug_screen @ 0x00410e00` |
| Gate parameter | `aaksjdkfj` | confirmed identical |
| Gate value | `!@dnjsrureljrm*&` (as published) | `!@dnjsrurelqjrm*&` -- **the CVE write-up is missing a 'q'**; ours is decompile-verified AND dynamically confirmed to be the value that actually passes the gate |
| CVSS | 3.1: 5.0 MEDIUM (`AC:H/PR:L`) | consistent with our findings: 3 stacked preconditions ahead of the sink, none of them pre-auth |

## Full gate chain -- every gate individually decompiled and its exact
## requirement resolved (`logs/05-decompile-gates.log`)

| Gate | Function (address) | Requirement (resolved this session) |
|---|---|---|
| 1 | `get_remote_support()` (`timepro.cgi @ 0x0040d42c`) | `iconfig_get_intvalue_direct("remote_support")` must be non-zero. Key absent from the shipped `default/etc/iconfig.cfg` -> **off by default**, an admin must have turned on the "remote support" UI option. |
| 2 | `check_default_pass()` (`libsysauth.so @ 0x11080`) | **NOT a plaintext password check.** Calls `sysauth_get_cred()` -> `iconfig_get("sys_auth_cred", ...)` (a config key holding `hex(SHA256(login)) + hex(SHA256(password))`, 128 hex chars) and compares it, via `sysauth_create_creds()` (SHA256 each of the *factory-default* login/password, `"admin"/"admin"`, read from `default/etc/iconfig.cfg`), against that stored hash. Returns "IS default" (blocking us) unless the stored `sys_auth_cred` value differs from `hex(SHA256("admin"))+hex(SHA256("admin"))` -- i.e. the admin must have actually changed the password from the factory default. **This is the gate that silently blocked every earlier attempt in this project** (all prior test configs used a plaintext `password=` line, which this code path never reads at all). |
| 3 | `check_csrf_attack()` (`libesysapi.so @ 0x34dfc`) -> `FUN_00034ba4` (Referer/Host comparison) | `get_csrf_op()` defaults to **1 (ON)** when its key (`csrf_op`) is absent (opposite default polarity from gate 1) -- also absent from the shipped default config, so CSRF-referer-checking is ON out of the box. The check reads env vars named **bare `REFERER`/`HOST`** (not the standard CGI `HTTP_REFERER`/`HTTP_HOST`) and requires the Referer's host part to equal the Host header (ports stripped if `:80`), or fall in an admin-configurable CSRF whitelist. **A genuine, working Referer-based CSRF defense** -- a classic external-page CSRF cannot forge a matching Referer; this requires either a same-origin request (e.g. XSS on the router itself) or the router's CSRF whitelist containing the attacker's origin. This corrects the a3004t_ml_14_194 candidate doc's earlier looser claim that this finding is straightforwardly "CSRF-reachable." |
| 4 | dispatcher `strcmp(argv[0], "/cgibin/d.cgi")` | `argv[0]`/effective request path must literally be `/cgibin/d.cgi` (the vendor's own symlink), not `/cgibin/timepro.cgi`. |
| 5 | the 17-byte magic string | `aaksjdkfj` parameter must equal `!@dnjsrurelqjrm*&` exactly. |

## What was run and observed (this session, after resolving gates 2 and 3)

Environment: `bwrap --tmpfs /etc --bind <fake iconfig.cfg> /etc/iconfig.cfg`
(private mount namespace, real host `/etc` untouched) with:
```
remote_support=1
login=admin
sys_auth_cred=<hex(SHA256("admin")) + hex(SHA256("MyNonDefaultPass123"))>
```
plus `REFERER=http://192.168.0.1/sess-bin/login.cgi` and `HOST=192.168.0.1`
(matching hosts, satisfying gate 3 honestly rather than disabling the check),
`argv[0]=/cgibin/d.cgi`.

**Negative control** (`aaksjdkfj=wrongvalue`, everything else identical):
```
Content-type: text/html; charset=utf-8

```
Just the header, nothing else -- the function returns before any HTML is
built. No marker file created. (`logs/evidence3_negative_control.out`)

**Positive test 1** (`cmd=touch /tmp/pwned_cve14485`):
```
Content-type: text/html; charset=utf-8

<html>
...
<b>command = touch /tmp/pwned_cve14485</b><br><br><pre></pre>
```
**`/tmp/pwned_cve14485` was actually created on the host** (0 bytes, matches
`touch`'s behavior; QEMU user-mode has no chroot, so the emulated process's
`system()`-via-`popen()` call is a real host `/bin/sh` invocation). Cleaned
up afterward. (`logs/evidence3_positive_touch.out`)

**Positive test 2** (`cmd=id`, real output capture):
```
<b>command = id</b><br><br><pre>uid=1000 gid=1000 groups=1000,65534
</pre>
```
The `<pre>` block is `id`'s genuine stdout, captured by the CGI's own
`popen()`/`fgets()` loop and echoed into the HTTP response body -- exactly
matching the CVE's and the static candidate doc's description of the sink
behavior. (`logs/evidence3_positive_id.out`)

All three requests used the exact `run.sh`/`GUIDE.md` recipe now checked
into this kit -- re-run `bash run.sh` and the two `curl` commands in
`GUIDE.md` section 7 to reproduce.

## Root cause of the earlier (2026-08-18) failed attempts, now resolved

The prior attempt's `test_iconfig.cfg` used a plaintext `password=` line,
which `check_default_pass()` never reads (gate 2 above) -- and never even
attempted to satisfy gate 3 (the Referer/Host CSRF check) at all, since its
existence wasn't known until this session's full decompile pass. Both gates
required decompiling functions one level deeper than the immediately-calling
function (`check_default_pass()` -> `FUN_00010da4`/`sysauth_get_cred`/
`sysauth_create_creds`; `check_csrf_attack()` -> `FUN_00034ba4`) rather than
guessing from function names or config-file conventions seen elsewhere in
the codebase. No GDB was needed this time -- pure Ghidra headless decompile
of the four supporting functions (`logs/05-decompile-gates.log`) supplied
everything needed; the earlier `gdb-multiarch` crash and harness-classifier
block were bypassed entirely by not needing live register inspection at all.

## Host side effects (cleaned up)

Two empty 0-byte `/var/lock/*.lock` files (same known artifact as every
prior kit in this project) were created and removed after each test run.
No other host state was modified -- `/etc` was never touched (bwrap private
namespace), and all `/tmp/pwned_*` marker files were removed. All background
QEMU/bwrap/bridge processes were killed and verified gone.

## Evidence level: 3

Full chain -- static source-to-sink, CVE cross-referenced, every gate's real
semantics resolved via decompile, and live QEMU execution with a positive/
negative control pair proving both that the gate genuinely blocks incorrect
input and that correct input reaches a real, host-visible command execution
with captured output. Matches the rigor of the CVE-2025-55423 Evidence-3
result ([[project_cve_2025_55423_comparison]]).
