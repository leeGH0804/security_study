#!/usr/bin/env python3
"""
Local HTTP bridge for a QEMU-emulated firmware CGI binary.

Lets a human verify a documented CGI command-injection finding by opening a
URL in a browser or running curl, instead of hand-typing qemu argv commands.
Every request is translated into a `qemu-<arch>-static -L <stage> <bin>`
invocation and the CGI's raw stdout/stderr is shown back, plus logged to
verify.log next to this script's cwd.

SAFETY: binds to 127.0.0.1 ONLY. These are real, mostly-unpatched firmware
vulnerabilities -- never change --host to 0.0.0.0 or expose this port on a
real network.

Usage:
  cgi_verify_bridge.py --stage <stage_dir> --bin <relpath-inside-stage>
      --qemu qemu-mipsel-static --port 8081 [--url-path /cgibin/x.cgi]

Then: curl "http://127.0.0.1:8081/?cmd=id" or open that URL in a browser.
Query-string / POST-body key=value pairs are forwarded THREE ways at once,
since different vendor CGI libraries in this firmware family read params
differently: (1) as QUERY_STRING/CONTENT_LENGTH CGI env vars, (2) as
trailing "key=value" argv items (several binaries in this codebase parse
argv instead of env -- confirmed in prior sessions' results.md logs), and
(3) as raw stdin for POST. Whichever the target actually reads, it gets it.
"""
import argparse
import http.server
import os
import re
import subprocess
import sys
import time
import urllib.parse


def log(logfile, line):
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(logfile, "a") as f:
        f.write(f"[{stamp}] {line}\n")


def run_target(args, method, url_path, query_string, body):
    kv_pairs = urllib.parse.parse_qsl(query_string if method == "GET" else body.decode("utf-8", "replace"))
    argv_params = [f"{k}={v}" for k, v in kv_pairs]

    env = {
        "PATH": "/bin:/usr/bin:/sbin:/usr/sbin",
        "REQUEST_METHOD": method,
        "SCRIPT_NAME": url_path,
        "REQUEST_URI": url_path + (("?" + query_string) if query_string else ""),
        "QUERY_STRING": query_string,
        "CONTENT_LENGTH": str(len(body)),
        "CONTENT_TYPE": "application/x-www-form-urlencoded",
        "SERVER_PROTOCOL": "HTTP/1.1",
        "GATEWAY_INTERFACE": "CGI/1.1",
        "SERVER_SOFTWARE": "firmware-verify-bridge/1.0",
        "SERVER_NAME": "localhost",
        "SERVER_PORT": str(args.port),
        "REMOTE_ADDR": "127.0.0.1",
        "HTTP_COOKIE": args.cookie or "",
        # Some vendor CGI code in this codebase reads bare "REFERER"/"HOST" via
        # getenv() instead of the standard CGI "HTTP_REFERER"/"HTTP_HOST" names
        # (confirmed in timepro.cgi's check_csrf_attack(), CVE-2025-14485
        # engagement, 2026-08-19) -- set both spellings so either convention works.
        "HTTP_REFERER": args.referer or "",
        "REFERER": args.referer or "",
        "HTTP_HOST": args.host or "",
        "HOST": args.host or "",
    }

    bin_path = os.path.join(args.stage, args.bin)
    cmd = [args.qemu, "-0", args.url_path, "-L", args.stage, bin_path] + argv_params

    try:
        proc = subprocess.run(
            cmd, cwd=args.stage, env=env, input=body,
            capture_output=True, timeout=args.timeout,
        )
        return cmd, proc.returncode, proc.stdout, proc.stderr, None
    except subprocess.TimeoutExpired:
        return cmd, None, b"", b"", f"timed out after {args.timeout}s (daemon-style hang? check GUIDE.md)"


def split_cgi_output(raw):
    """CGI convention: headers, blank line, body. Falls back to raw dump if malformed."""
    # Line-by-line scan, NOT a naive "split on first blank line": some of this
    # firmware's CGI binaries print injected-command output directly after the
    # Content-type line with no blank-line separator (observed with CMDI-005's
    # check_txbf_cal_result() path) -- a bare \n\n split silently eats that
    # output into the "headers" block and drops it. Real CGI headers all look
    # like "Token: value"; the first line that doesn't match ends the header
    # block, whether or not a blank line preceded it.
    lines = raw.split(b"\n")
    headers = {}
    body_start = len(lines)
    for i, line in enumerate(lines):
        stripped = line.rstrip(b"\r")
        if stripped == b"":
            body_start = i + 1
            break
        m = re.match(rb"^[A-Za-z][A-Za-z0-9-]*:\s?", stripped)
        if not m:
            body_start = i
            break
        k, _, v = stripped.partition(b":")
        headers[k.strip().decode("latin1")] = v.strip().decode("latin1")
    body = b"\n".join(lines[body_start:])
    return headers, body


def make_handler(args, logfile):
    class Handler(http.server.BaseHTTPRequestHandler):
        def _handle(self, method):
            parsed = urllib.parse.urlparse(self.path)
            query_string = parsed.query
            body = b""
            if method == "POST":
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)

            log(logfile, f"{method} {self.path}  body={body[:200]!r}")
            cmd, rc, out, err, timeout_msg = run_target(args, method, args.url_path, query_string, body)
            log(logfile, f"  cmd={' '.join(cmd)}")
            log(logfile, f"  rc={rc} stdout_len={len(out)} stderr_len={len(err)}")
            if err:
                log(logfile, f"  stderr: {err[:2000]!r}")

            if timeout_msg:
                self.send_response(504)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(f"[bridge] {timeout_msg}\n".encode())
                return

            headers, cgi_body = split_cgi_output(out)
            self.send_response(200)
            if "Content-type" in headers or "Content-Type" in headers:
                for k, v in headers.items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(cgi_body)
            else:
                # Target didn't emit valid CGI headers -- dump everything raw so a
                # learner can still see exactly what happened (crash, no output, etc.)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"--- raw stdout (no CGI headers detected) ---\n")
                self.wfile.write(out)
                if err:
                    self.wfile.write(b"\n--- stderr ---\n")
                    self.wfile.write(err)

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

        def log_message(self, fmt, *a):
            pass  # quiet -- we do our own structured logging to verify.log

    return Handler


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--stage", required=True, help="staged rootfs dir (built by stage_rootfs.sh)")
    p.add_argument("--bin", required=True, help="path to the CGI binary, relative to --stage")
    p.add_argument("--qemu", required=True, help="e.g. qemu-mipsel-static / qemu-arm-static")
    p.add_argument("--port", type=int, default=8081)
    p.add_argument("--url-path", default="/cgibin/target.cgi", help="what SCRIPT_NAME/-0 argv0 should look like")
    p.add_argument("--cookie", default="", help="raw Cookie header value, for session-gated findings")
    p.add_argument("--referer", default="", help="Referer header/env value, for CSRF-referer-check-gated findings")
    p.add_argument("--host", default="", help="Host header/env value, must match --referer's host for CSRF-referer-check-gated findings")
    p.add_argument("--timeout", type=int, default=10)
    args = p.parse_args()

    args.stage = os.path.abspath(args.stage)
    bin_abspath = os.path.join(args.stage, args.bin)
    if not os.path.isfile(bin_abspath):
        sys.exit(f"[!] {bin_abspath} not found -- check --stage/--bin")

    logfile = os.path.join(os.getcwd(), "verify.log")
    handler = make_handler(args, logfile)
    server = http.server.HTTPServer(("127.0.0.1", args.port), handler)

    print(f"[*] Bridging http://127.0.0.1:{args.port}/  ->  {args.qemu} -L {args.stage} {args.bin}")
    print(f"[*] Requests/responses are logged to: {logfile}")
    print(f"[*] Example: curl 'http://127.0.0.1:{args.port}/?param=value'")
    print(f"[*] SAFETY: bound to 127.0.0.1 only. Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Stopped.")


if __name__ == "__main__":
    main()
