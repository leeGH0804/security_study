#!/bin/bash
# CMDI-B-timepro-debug (== CVE-2025-14485) -- one-command verification launcher
#
# This kit seeds a minimal /etc/iconfig.cfg (via bwrap's private mount
# namespace -- the real host /etc/iconfig.cfg is never touched) so all three
# preconditions ahead of the popen() sink are satisfied:
#   - remote_support=1                (get_remote_support() gate)
#   - sys_auth_cred=<non-default hash pair>  (check_default_pass() gate --
#     NOT a plaintext "password=" field; it's hex(SHA256(login))+hex(SHA256(pass))
#     compared against hex(SHA256("admin"))+hex(SHA256("admin")), the real
#     factory default -- see GUIDE.md section 3 for how this was derived)
# and this script passes a matching --referer/--host pair so
# check_csrf_attack()'s Referer-vs-Host comparison also passes (that check
# reads bare env vars "REFERER"/"HOST", not the standard CGI "HTTP_REFERER"/
# "HTTP_HOST" -- both spellings are set by cgi_verify_bridge.py's --referer/
# --host flags as of this engagement).
#
# Usage:
#   ./run.sh [port]     (default port: 8082)
#
# Then, in ANOTHER terminal, see GUIDE.md for the exact curl commands.
# IMPORTANT: the URL path must be /cgibin/d.cgi (NOT /cgibin/timepro.cgi) --
# the top-level dispatcher does `strcmp(argv[0], "/cgibin/d.cgi")` to select
# show_debug_screen; any other argv[0] routes elsewhere and produces silent
# empty output.
#
# Standalone package note: this copy is fully self-contained (rootfs/ +
# scripts/cgi_verify_bridge.py are bundled alongside this script) -- it does
# NOT depend on ~/.claude/skills/firmware-cmdi-pipeline being present on this
# machine. It still needs these 3 host tools installed: qemu-mipsel-static,
# bwrap (bubblewrap), python3. On Debian/Ubuntu:
#   sudo apt install qemu-user-static bubblewrap python3
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${1:-8082}"

for dep in qemu-mipsel-static bwrap python3; do
  command -v "$dep" >/dev/null 2>&1 || { echo "missing required tool: $dep" >&2; exit 1; }
done

NONDEFAULT_HASH="$(python3 -c "import hashlib; print(hashlib.sha256(b'admin').hexdigest()+hashlib.sha256(b'MyNonDefaultPass123').hexdigest())")"

cat > "$HERE/test_iconfig.cfg" <<CFG
remote_support=1
login=admin
sys_auth_cred=${NONDEFAULT_HASH}
CFG

exec bwrap --bind / / --tmpfs /etc --bind /etc/ld.so.cache /etc/ld.so.cache \
  --bind "$HERE/test_iconfig.cfg" /etc/iconfig.cfg -- \
  python3 "$HERE/scripts/cgi_verify_bridge.py" \
  --stage "$HERE/rootfs" \
  --bin cgibin/timepro.cgi \
  --qemu qemu-mipsel-static \
  --port "$PORT" \
  --url-path /cgibin/d.cgi \
  --referer "http://192.168.0.1/sess-bin/login.cgi" \
  --host "192.168.0.1"
